import "dotenv/config";
import express from "express";
import multer from "multer";
import OpenAI from "openai";
import pdfParse from "pdf-parse";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const port = Number(process.env.PORT || 3000);
const maxUploadMb = Number(process.env.MAX_UPLOAD_MB || 10);
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: maxUploadMb * 1024 * 1024, files: 5 },
});
const allowedExtensions = new Set([
  ".png", ".jpg", ".jpeg", ".webp", ".gif",
  ".txt", ".md", ".csv", ".json", ".pdf"
]);

app.use(express.json({ limit: "1mb" }));
app.use(express.static(path.join(__dirname, "public")));

function getClient() {
  if (!process.env.OPENAI_API_KEY) {
    const error = new Error("The server is missing OPENAI_API_KEY. Add it to your .env file and restart the server.");
    error.status = 503;
    throw error;
  }
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, configured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", upload.array("files", 5), async (req, res) => {
  try {
    const client = getClient();
    const message = String(req.body.message || "").trim();
    let history = [];
    try {
      history = JSON.parse(req.body.history || "[]");
      if (!Array.isArray(history)) history = [];
    } catch {
      history = [];
    }

    if (!message && !(req.files || []).length) {
      return res.status(400).json({ error: "Write a message or attach a file first." });
    }

    // Keep only a small, validated conversation window from the browser.
    const previous = history.slice(-12).map((item) => {
      const role = item?.role === "assistant" ? "assistant" : "user";
      return { role, content: String(item?.content || "").slice(0, 8000) };
    });

    const content = [];
    if (message) content.push({ type: "input_text", text: message });

    for (const file of req.files || []) {
      const ext = path.extname(file.originalname || "").toLowerCase();
      if (!allowedExtensions.has(ext)) {
        return res.status(415).json({
          error: `Unsupported file type: ${file.originalname}. Allowed: images, PDF, TXT, MD, CSV, and JSON.`
        });
      }

      if ([".png", ".jpg", ".jpeg", ".webp", ".gif"].includes(ext)) {
        const mime = file.mimetype || "application/octet-stream";
        if (!mime.startsWith("image/")) {
          return res.status(415).json({ error: `The file ${file.originalname} is not recognized as an image.` });
        }
        content.push({
          type: "input_image",
          image_url: `data:${mime};base64,${file.buffer.toString("base64")}`
        });
        content.push({ type: "input_text", text: `Attached image: ${file.originalname}` });
      } else if (ext === ".pdf") {
        const parsed = await pdfParse(file.buffer);
        const extracted = String(parsed.text || "").slice(0, 30000);
        content.push({
          type: "input_text",
          text: `Extracted text from PDF "${file.originalname}":\n${extracted || "[No selectable text found in this PDF. It may be a scanned document.]"}`
        });
      } else {
        content.push({
          type: "input_text",
          text: `Contents of attached file "${file.originalname}":\n${file.buffer.toString("utf8").slice(0, 30000)}`
        });
      }
    }

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-4.1-mini",
      instructions: [
        "You are Nexus AI, a helpful assistant.",
        "Reply in the language the user uses, including Urdu when appropriate.",
        "If the user mixes Urdu and English, you may answer bilingually.",
        "Be clear and honest. Never claim to have performed actions you did not perform.",
        "When attachments are provided, use their available contents and say if the content could not be read."
      ].join(" "),
      input: [
        ...previous,
        { role: "user", content }
      ],
      max_output_tokens: 1200
    });

    res.json({ reply: response.output_text || "I couldn't produce a text response. Please try again." });
  } catch (error) {
    console.error("Chat API error:", error?.message || error);
    const status = Number(error?.status) >= 400 && Number(error?.status) < 600 ? Number(error.status) : 500;
    let message = error?.message || "Something went wrong while generating the response.";
    if (status === 401) message = "The API key was rejected. Check OPENAI_API_KEY in your .env file.";
    if (status === 429) message = "The API rate limit or account quota was reached. Check your API usage and billing.";
    if (status === 503) message = error.message;
    res.status(status).json({ error: message });
  }
});

app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(port, () => {
  console.log(`Nexus AI running at http://localhost:${port}`);
});
