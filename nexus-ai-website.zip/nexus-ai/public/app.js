const $ = (id) => document.getElementById(id);
const messagesEl = $("messages");
const input = $("userInput");
const fileInput = $("fileInput");
const attachmentTray = $("attachmentTray");
const sendBtn = $("sendBtn");
const chatList = $("chatList");
const langSelect = $("languageSelect");
const STORAGE_KEY = "nexus-ai-chats-v1";
const LANG_KEY = "nexus-ai-ui-language";
let chats = loadChats();
let activeChatId = chats[0]?.id || null;
let pendingFiles = [];
let isSending = false;
let toastTimer;

const translations = {
  en: {
    tagline:"Next-generation assistant",checking:"Checking…",online:"AI ready",offline:"API not configured",
    newChat:"New chat",history:"CHAT HISTORY",startChat:"Start a new chat",localHistory:"History is saved in this browser",
    workspace:"YOUR WORKSPACE",assistant:"Nexus Assistant",welcomeEyebrow:"A LITTLE MORE INTELLIGENCE",
    welcomeTitle:"What can we explore today?",welcomeCopy:"Ask a question, upload a document, or start with an idea.",
    suggest1:"Explain a difficult topic",suggest2:"Write a YouTube script",suggest3:"Understand a document",suggest4:"Discover a history fact",
    send:"Send",composerHint:"Enter to send · Shift + Enter for a new line",
    disclaimer:"AI can make mistakes. Check important information.",placeholder:"Message Nexus AI…",
    listening:"Listening…",voiceUnsupported:"Voice input is not supported in this browser. Try Chrome.",empty:"Write a message or attach a file first.",
    failed:"Could not send your message.",confirmClear:"Delete all locally saved chat history?",newTitle:"New conversation",
    uploadLimit:"You can attach up to 5 files, each up to 10 MB.",fileType:"This file type is not supported.",
    micPermission:"Voice input could not start. Check microphone permissions."
  },
  ur: {
    tagline:"نئی نسل کا ذہین معاون",checking:"جانچ جاری ہے…",online:"AI تیار ہے",offline:"API کنفیگر نہیں",
    newChat:"نئی چیٹ",history:"چیٹ کی سرگزشت",startChat:"نئی چیٹ شروع کریں",localHistory:"سرگزشت اسی براؤزر میں محفوظ ہے",
    workspace:"آپ کا ورک اسپیس",assistant:"نیکسس معاون",welcomeEyebrow:"ذہانت کا ایک نیا انداز",
    welcomeTitle:"آج کیا دریافت کریں؟",welcomeCopy:"سوال پوچھیں، دستاویز اپ لوڈ کریں یا کوئی خیال شروع کریں۔",
    suggest1:"مشکل موضوع آسانی سے سمجھیں",suggest2:"یوٹیوب اسکرپٹ لکھیں",suggest3:"دستاویز سمجھیں",suggest4:"تاریخ کی دلچسپ بات جانیں",
    send:"بھیجیں",composerHint:"بھیجنے کے لیے Enter · نئی سطر کے لیے Shift + Enter",
    disclaimer:"AI سے غلطی ہو سکتی ہے۔ اہم معلومات کی تصدیق کریں۔",placeholder:"نیکسس AI کو پیغام لکھیں…",
    listening:"سن رہا ہے…",voiceUnsupported:"اس براؤزر میں وائس ان پٹ دستیاب نہیں۔ Chrome آزمائیں۔",empty:"پہلے پیغام لکھیں یا فائل منسلک کریں۔",
    failed:"پیغام نہیں بھیجا جا سکا۔",confirmClear:"کیا تمام محفوظ چیٹس حذف کرنی ہیں؟",newTitle:"نئی گفتگو",
    uploadLimit:"زیادہ سے زیادہ 5 فائلیں، ہر ایک 10 MB تک منسلک کریں۔",fileType:"یہ فائل فارمیٹ سپورٹ نہیں ہے۔",
    micPermission:"وائس ان پٹ شروع نہیں ہو سکا۔ مائیکروفون کی اجازت چیک کریں۔"
  }
};
function uiLanguage() { return langSelect.value === "ur" ? "ur" : "en"; }
function tr(key) { return (translations[uiLanguage()] || translations.en)[key] || translations.en[key] || key; }
function loadChats() {
  try { const value = JSON.parse(localStorage.getItem(STORAGE_KEY) || "[]"); return Array.isArray(value) ? value : []; }
  catch { return []; }
}
function saveChats() {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(chats.slice(0,30))); }
  catch { showToast("Browser storage is full. Consider clearing older chats."); }
}
function uid() { return `${Date.now()}-${Math.random().toString(36).slice(2,8)}`; }
function createChat() {
  const chat = { id:uid(), title:tr("newTitle"), messages:[], updatedAt:Date.now() };
  chats.unshift(chat); activeChatId = chat.id; saveChats(); renderAll(); input.focus();
}
function activeChat() { return chats.find(c => c.id === activeChatId); }
function ensureChat() { if (!activeChat()) createChat(); return activeChat(); }
function escapeHTML(value) {
  return String(value).replace(/[&<>"']/g, ch => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[ch]));
}
function formatTime(ts) { return new Date(ts || Date.now()).toLocaleTimeString([], {hour:"2-digit",minute:"2-digit"}); }
function showToast(message) {
  const toast = $("toast"); toast.textContent = message; toast.classList.add("show");
  clearTimeout(toastTimer); toastTimer = setTimeout(() => toast.classList.remove("show"), 3000);
}
function renderAll() { renderChatList(); renderMessages(); applyLanguage(); }
function renderChatList() {
  chatList.innerHTML = "";
  if (!chats.length) {
    const empty = document.createElement("p"); empty.className = "history-empty";
    empty.style.cssText = "font-size:11px;color:#64748b;line-height:1.7;padding:6px";
    empty.textContent = uiLanguage() === "ur" ? "ابھی کوئی چیٹ محفوظ نہیں۔" : "Your conversations will appear here.";
    chatList.append(empty); return;
  }
  chats.forEach(chat => {
    const button = document.createElement("button");
    button.className = "history-item" + (chat.id === activeChatId ? " active" : "");
    button.type = "button";
    const title = document.createElement("span"); title.textContent = chat.title || tr("newTitle");
    const time = document.createElement("small"); time.textContent = new Date(chat.updatedAt || Date.now()).toLocaleDateString([], {month:"short",day:"numeric"});
    button.append("◈", title, time);
    button.addEventListener("click", () => { activeChatId = chat.id; renderAll(); $("sidebar").classList.remove("open"); });
    chatList.append(button);
  });
}
function renderMessages() {
  messagesEl.innerHTML = "";
  const chat = activeChat();
  if (!chat || !chat.messages.length) {
    const welcome = document.createElement("div"); welcome.id = "welcome"; welcome.className = "welcome";
    welcome.innerHTML = `<div class="welcome-symbol">✧</div><p class="eyebrow" data-i18n="welcomeEyebrow"></p><h2 data-i18n="welcomeTitle"></h2><p class="welcome-copy" data-i18n="welcomeCopy"></p><div class="suggestions"><button class="suggestion" data-prompt="Explain a difficult topic simply, with an example."><span>◈</span><span data-i18n="suggest1"></span><b>↗</b></button><button class="suggestion" data-prompt="Help me write a polished YouTube video script."><span>▤</span><span data-i18n="suggest2"></span><b>↗</b></button><button class="suggestion" data-prompt="Help me understand and summarize an uploaded file."><span>⌁</span><span data-i18n="suggest3"></span><b>↗</b></button><button class="suggestion" data-prompt="Teach me something surprising about history."><span>✳</span><span data-i18n="suggest4"></span><b>↗</b></button></div>`;
    messagesEl.append(welcome); applyLanguage();
    welcome.querySelectorAll("[data-prompt]").forEach(b => b.addEventListener("click", () => { input.value = b.dataset.prompt; resizeInput(); input.focus(); }));
    return;
  }
  chat.messages.forEach(message => {
    const row = document.createElement("article"); row.className = "message " + (message.role === "user" ? "user" : "assistant");
    const avatar = document.createElement("div"); avatar.className = "avatar"; avatar.textContent = message.role === "user" ? "U" : "✧";
    const bubble = document.createElement("div"); bubble.className = "bubble";
    const content = document.createElement("div"); content.textContent = message.content || "";
    bubble.append(content);
    if (message.files?.length) {
      const fileWrap = document.createElement("div");
      message.files.forEach(f => { const chip = document.createElement("span"); chip.className = "file-chip"; chip.textContent = "▧ " + f; fileWrap.append(chip); });
      bubble.append(fileWrap);
    }
    const meta = document.createElement("span"); meta.className = "meta"; meta.textContent = (message.role === "user" ? "You" : "Nexus AI") + " · " + formatTime(message.createdAt);
    bubble.append(meta); row.append(avatar,bubble); messagesEl.append(row);
  });
  messagesEl.scrollTop = messagesEl.scrollHeight;
}
function applyLanguage() {
  const lang = uiLanguage();
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ur" ? "rtl" : "ltr";
  document.querySelectorAll("[data-i18n]").forEach(el => { const key = el.dataset.i18n; if (translations[lang][key]) el.textContent = translations[lang][key]; });
  input.placeholder = tr("placeholder");
  $("charCount").textContent = `${input.value.length} / 8000`;
}
function resizeInput() { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight,180) + "px"; }
function setSending(value) { isSending = value; sendBtn.disabled = value; sendBtn.querySelector("span:first-child").textContent = value ? "…" : tr("send"); }
function showTyping() {
  const row = document.createElement("article"); row.className = "message assistant"; row.id = "typingIndicator";
  row.innerHTML = `<div class="avatar">✧</div><div class="bubble"><div class="typing"><span></span><span></span><span></span></div></div>`;
  messagesEl.append(row); messagesEl.scrollTop = messagesEl.scrollHeight;
}
function validateFiles(files) {
  const allowed = /\.(png|jpe?g|webp|gif|txt|md|csv|json|pdf)$/i;
  if (pendingFiles.length + files.length > 5) { showToast(tr("uploadLimit")); return; }
  for (const file of files) {
    if (!allowed.test(file.name)) { showToast(`${tr("fileType")} ${file.name}`); continue; }
    if (file.size > 10 * 1024 * 1024) { showToast(`${file.name}: maximum 10 MB.`); continue; }
    pendingFiles.push(file);
  }
  renderAttachments();
}
function renderAttachments() {
  attachmentTray.innerHTML = ""; attachmentTray.hidden = pendingFiles.length === 0;
  pendingFiles.forEach((file,index) => {
    const chip = document.createElement("div"); chip.className = "attachment";
    const name = document.createElement("span"); name.className = "attachment-name"; name.textContent = file.name;
    const remove = document.createElement("button"); remove.type = "button"; remove.textContent = "×"; remove.setAttribute("aria-label","Remove "+file.name);
    remove.addEventListener("click", () => { pendingFiles.splice(index,1); renderAttachments(); });
    chip.append("▧ ",name,remove); attachmentTray.append(chip);
  });
}
async function sendMessage() {
  if (isSending) return;
  const text = input.value.trim();
  if (!text && !pendingFiles.length) { showToast(tr("empty")); return; }
  const chat = ensureChat();
  const files = [...pendingFiles];
  const fileNames = files.map(f => f.name);
  const userMessage = { role:"user", content:text || (uiLanguage() === "ur" ? "منسلک فائلوں کا تجزیہ کریں۔" : "Please analyze the attached file(s)."), files:fileNames, createdAt:Date.now() };
  chat.messages.push(userMessage);
  if (chat.messages.filter(m => m.role === "user").length === 1) chat.title = (text || fileNames[0] || tr("newTitle")).slice(0,38);
  chat.updatedAt = Date.now(); saveChats();
  input.value = ""; resizeInput(); pendingFiles = []; renderAttachments(); applyLanguage(); renderAll();
  setSending(true); showTyping();

  const form = new FormData();
  form.append("message", userMessage.content);
  // Send the preceding text-only context; attachments from prior turns aren't resent.
  const history = chat.messages.slice(0,-1).filter(m => m.role === "user" || m.role === "assistant").slice(-12).map(m => ({role:m.role,content:m.content}));
  form.append("history", JSON.stringify(history));
  files.forEach(file => form.append("files",file));
  try {
    const response = await fetch("/api/chat", { method:"POST", body:form });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || tr("failed"));
    chat.messages.push({ role:"assistant", content:data.reply || "", createdAt:Date.now() });
    chat.updatedAt = Date.now();
  } catch (error) {
    chat.messages.push({ role:"assistant", content:`⚠ ${error.message || tr("failed")}`, createdAt:Date.now() });
  } finally {
    $("typingIndicator")?.remove(); setSending(false); saveChats(); renderAll(); input.focus();
  }
}
$("composer").addEventListener("submit", e => { e.preventDefault(); sendMessage(); });
input.addEventListener("input", () => { resizeInput(); $("charCount").textContent = `${input.value.length} / 8000`; if (input.value.length > 8000) input.value = input.value.slice(0,8000); });
input.addEventListener("keydown", e => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); sendMessage(); } });
$("attachBtn").addEventListener("click", () => fileInput.click());
fileInput.addEventListener("change", () => { validateFiles([...fileInput.files]); fileInput.value = ""; });
$("newChatBtn").addEventListener("click", createChat);
$("sidebarNewChat").addEventListener("click", () => { createChat(); $("sidebar").classList.remove("open"); });
$("clearHistoryBtn").addEventListener("click", () => {
  if (!confirm(tr("confirmClear"))) return;
  chats = []; activeChatId = null; saveChats(); createChat();
});
$("mobileHistoryBtn").addEventListener("click", () => $("sidebar").classList.toggle("open"));
langSelect.value = localStorage.getItem(LANG_KEY) || "auto";
langSelect.addEventListener("change", () => { try { localStorage.setItem(LANG_KEY,langSelect.value); } catch {} renderAll(); });
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
let recognition = null;
if (SpeechRecognition) {
  recognition = new SpeechRecognition(); recognition.continuous = false; recognition.interimResults = true;
  recognition.onstart = () => { $("voiceBtn").classList.add("recording"); input.placeholder = tr("listening"); };
  recognition.onend = () => { $("voiceBtn").classList.remove("recording"); input.placeholder = tr("placeholder"); };
  recognition.onerror = () => showToast(tr("micPermission"));
  recognition.onresult = event => {
    let transcript = "";
    for (let i=0;i<event.results.length;i++) transcript += event.results[i][0].transcript;
    input.value = transcript; resizeInput(); $("charCount").textContent = `${input.value.length} / 8000`;
  };
}
$("voiceBtn").addEventListener("click", () => {
  if (!recognition) { showToast(tr("voiceUnsupported")); return; }
  try {
    const lang = uiLanguage();
    recognition.lang = lang === "ur" ? "ur-PK" : "en-US";
    recognition.start();
  } catch { showToast(tr("micPermission")); }
});
async function checkHealth() {
  const status = $("connectionStatus");
  try {
    const res = await fetch("/api/health"); const data = await res.json();
    status.className = "status-pill " + (data.configured ? "online" : "offline");
    status.querySelector("span").textContent = data.configured ? tr("online") : tr("offline");
  } catch {
    status.className = "status-pill offline"; status.querySelector("span").textContent = tr("offline");
  }
}
renderAll();
if (!activeChatId) createChat();
checkHealth();
