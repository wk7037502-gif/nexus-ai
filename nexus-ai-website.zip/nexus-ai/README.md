# Nexus AI — complete starter website

A responsive bilingual (English/Urdu) AI chat website based on your original neon/glassmorphism design.

## Included

- Real AI replies through the OpenAI API (server-side; API key is never placed in browser code)
- Responsive layout for mobile, tablet, and desktop
- Local chat history in the current browser
- Voice dictation using the browser's Web Speech API (browser/device support varies)
- Image uploads for visual questions
- PDF, TXT, Markdown, CSV, and JSON attachments
- English and Urdu interface options, plus assistant replies that follow the user's language
- Upload limits, loading indicator, and basic API error messages

## Requirements

- Node.js 20 or newer
- An OpenAI API key with API access and available billing/usage quota

## Run locally

1. Extract this project folder.
2. Open a terminal in the project folder.
3. Install dependencies:

   ```bash
   npm install
   ```

4. Copy `.env.example` to a new file named `.env`.
5. Edit `.env` and set your key:

   ```env
   OPENAI_API_KEY=your_real_api_key_here
   OPENAI_MODEL=gpt-4.1-mini
   PORT=3000
   MAX_UPLOAD_MB=10
   ```

6. Start the server:

   ```bash
   npm start
   ```

7. Open `http://localhost:3000` in your browser.

**Do not share your `.env` file or commit it to Git.** API usage may incur charges according to your OpenAI account's current pricing and limits.

## Publish it

Deploy to a Node.js hosting provider that supports persistent environment variables (for example, Render, Railway, or another Node host):

1. Upload this project to a private Git repository.
2. Create a new Node web service connected to that repository.
3. Set the build/install command to `npm install`.
4. Set the start command to `npm start`.
5. Add `OPENAI_API_KEY` and optionally `OPENAI_MODEL` as environment variables in the hosting dashboard.
6. Deploy and open the HTTPS URL the host provides.

Do not publish your API key in `public/app.js`, `public/index.html`, or any other frontend file.

## Important behavior / limitations

- Chat history is stored in the visitor's browser using `localStorage`; it is not synced across devices or accounts. Clearing browser data removes it.
- Voice input depends on browser speech-recognition support and microphone permission. The feature is usually best supported in Chromium-based browsers and generally requires HTTPS outside localhost.
- PDF support extracts selectable text. Scanned/image-only PDFs may not produce readable text.
- Images and files are sent to your server and then to the AI API for the request. Tell users what data is processed if you publish this publicly.
- This starter has no user login, server-side shared history, rate limiting, or abuse protection. Before opening it to the public, add rate limiting, authentication or access controls as appropriate, request-cost limits, and a privacy policy.
- Uploads are limited to five files per request and 10 MB per file by default. The frontend accepts common image types, PDF, TXT, MD, CSV, and JSON.
- The included model name is a configurable default. Change `OPENAI_MODEL` to a model available to your API account.
